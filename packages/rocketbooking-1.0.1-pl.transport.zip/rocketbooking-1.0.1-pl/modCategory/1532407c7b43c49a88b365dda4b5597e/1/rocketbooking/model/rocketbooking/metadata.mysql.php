<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' =>
  array (
    0 => 'RocketBookingEvent',
    1 => 'RocketBookingTable',
    2 => 'RocketBookingSeat',
  ),
);
