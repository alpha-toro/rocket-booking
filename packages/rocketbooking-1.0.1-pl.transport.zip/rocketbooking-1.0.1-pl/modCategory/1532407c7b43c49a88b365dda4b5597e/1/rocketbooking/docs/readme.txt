--------------------
RocketBooking
--------------------
Author: Wayne Roddy <wayne@rocketcitydigital.com>
--------------------

An Booking Manager for MODx Revolution.

View the quick start on GitHub: https://github.com/Rocket-City-Digital/rocket-booking

Feel free to suggest ideas/improvements/bugs on GitHub:
https://github.com/Rocket-City-Digital/rocket-booking/issues


--------------------
Copyright Information

RocketBooking is distributed as GPL.
